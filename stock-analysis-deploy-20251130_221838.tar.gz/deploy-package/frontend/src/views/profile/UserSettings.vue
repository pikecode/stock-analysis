<script setup lang="ts">
</script>

<template>
  <div class="user-settings">
    <h1>账户设置</h1>
    <el-card>
      <el-empty description="账户设置功能开发中" />
    </el-card>
  </div>
</template>

<style scoped>
.user-settings {
  padding: 20px;
}
h1 {
  margin-bottom: 24px;
}
</style>
