<script setup lang="ts">
</script>

<template>
  <div class="analysis-page">
    <h1>投资组合分析</h1>
    <el-card>
      <el-empty description="投资组合分析功能开发中" />
    </el-card>
  </div>
</template>

<style scoped>
.analysis-page {
  padding: 20px;
}
h1 {
  margin-bottom: 24px;
}
</style>
